package collections_01;

import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * @author Kokes
 */
public class NewClass {
    
    // internal variables
    private LinkedList queue = new LinkedList();
    
    // push string into list
    public void pushItem(Object item){
        queue.addFirst(item);        
    }
    
    // pop string from the end of list
    public Object popItem(){
        String s = (String) queue.getLast();
        queue.removeLast();
        // alternatively: s = (String) queue.pollLast();
        return s;
    }
    
    // list the whole contents
    public String getContents(){
        return queue.toString();
    }
    
    // list the formated whole contents
    public String getContentsFormated(){
        String s = "";
        ListIterator itr = queue.listIterator();
        while (itr.hasNext()){
            Object element = itr.next();
            s = s + element + "\n";
        }              
        return s;
    }
    
}
