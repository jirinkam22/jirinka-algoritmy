/*
 * The MIT License
 *
 * Copyright 2014 Kokes.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package queuelistexample;

/**
 *
 * Queue as a linked list
 * @author Kokes
 */
public class QueueList {
    private Node first;
    private Node last;
    private int size;
    public QueueList() {
        this.size = 0;
    }

    /**
     * Appends one item
     * @param i item to be inserted
     */
    public void addLast(String i) {
        Node n = new Node(i);
        if(getSize() == 0) {
            this.first = n;
            this.last = n;
        } else {
            this.last.next = n;
            this.last = n;
        }
        size++;     
    }

    /**
     * Removes first node from queue
     * @return first item
     */
    public String deteteFirst() {
        if(getSize() == 0) throw new IllegalStateException("Queue empty");
        String value = first.value;
        first = first.next;
        size--;
        return value;
    }
    
    /**
     * Gets first item of queue 
     * @return first item
     */
    public String getFirst() {
        if(getSize() == 0) throw new IllegalStateException("Queue empty");
        return first.value;
    }    
    
    /**
     * Gets count of items
     * @return count
     */
    public int getSize() {
        return size;
    }
    
    /**
     * Query if queue is empty
     * @return true if empty, false otherwise
     */
    public boolean isEmpty() {
        return this.size == 0;
    }

    /**
     * Returns textual representation of Queue
     * @return returns textual representation of queueu
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        Node curr = first;
        for(int i = 0;  i < this.size; i++) {
            builder.append(curr.value).append(" ");
            curr = curr.next;
        }
        return builder.toString();
    }  

    /**
     * Internal implementation of node
     */
    private class Node {
        private String value;
        private Node next;
        private Node(String value) {
            this.value = value;
        }
    }    
    
}
