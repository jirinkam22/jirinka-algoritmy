/*
 * The MIT License
 *
 * Copyright 2014 Virtual.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package circularqueuearrayexample;

/**
 *
 * Circular queue implemented by array
 * @author Kokes
 */
public class CircularQueueArray<TYPE> {

    private int size;
    private final Object[] array;
    private int pointer; //first free index

    /**
     * Constructor
     * @param length initial size of array
     */
    public CircularQueueArray(int length) {
        this.array = new Object[length];
        this.size = 0;
        pointer = 0;
    }

    /**
     * Append item
     * @param i item
     */
    public void addLast(TYPE i) {
        if (this.size == array.length) {
            throw new IllegalStateException("Buffer full");
        }
        array[pointer] = i;
        pointer = modulo((pointer + 1), array.length);
        size++;
    }

    /**
     * Get and remove first item
     * @return first item
     */
    public TYPE getFirst() {
        if (this.size == 0) {
            throw new IllegalStateException("Buffer empty");
        }
        TYPE value = (TYPE) array[modulo((pointer - size), array.length)];        
        array[modulo((pointer - size), array.length)] = null;
        size--;        
        return value;
    }

    /**
     * Get first item
     * @return first item
     */
    public TYPE readFirst() {
        if (this.size == 0) {
            throw new IllegalStateException("Buffer empty");
        }
        TYPE value = (TYPE) array[modulo((pointer - size), array.length)];
        return value;
    }

    /**
     * @param number number
     * @param modulo modulo
     * @return the smallest non-negative residuum
     */
    private int modulo(int number, int modulo) {
        if (number >= 0) {
            return number % modulo;
        }
        int result = number % modulo;
        return result == 0 ? 0 : result + modulo;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Content: ");
        for (int i = 0; i < size; i++) {
            builder.append(array[modulo((pointer - size + i), array.length)]).append(" ");
        }
        builder.append("\nfirst index: ").append(modulo((pointer - size), array.length)).append(", last index:").append(pointer - 1).append(", size: ").append(size);
        return builder.toString();
    }

    /**
     * Count of items in queue
     * @return count
     */
    public int getSize() {
        return this.size;
    }

    /**
     * Get maximum count of items
     * @return maximum count of items
     */
    public int getLength() {
        return array.length;
    }
}
