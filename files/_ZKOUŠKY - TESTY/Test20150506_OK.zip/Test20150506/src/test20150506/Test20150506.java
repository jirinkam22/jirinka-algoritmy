/*
    Je dán soubor, obsahující méně než 1000 celých čísel.
    Program má všechny tyto čísla najít, sečíst a najít median.

    Given a file containing less tham 1000 integer numbers.
    Program must find all numbers, sum them and find a median.

 */
package test20150506;

public class Test20150506 {

    public static void main(String[] args) {
        Comp comp = new Comp("MyFile.txt");
        comp.read();
        System.out.println("sum = " + comp.getSum());
        System.out.println("medien = " + comp.getMedian());
    }
    
}
