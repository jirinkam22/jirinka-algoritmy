/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author Virtual
 */
public class FileIO {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        FileReader fr = new FileReader("a.txt");
        BufferedReader orig = new BufferedReader(fr);
        FileWriter fw = new FileWriter("b.txt");
        BufferedWriter copy = new BufferedWriter(fw);
        String s;
        
        while((s = orig.readLine()) != null) {
            System.out.println(s);
            copy.write(s);
            copy.newLine();
        }
        
        fr.close();
        copy.close();
    }
    
}
