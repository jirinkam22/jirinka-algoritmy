/*
 * The MIT License
 *
 * Copyright 2014 Kokes.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package stacklistexample;

/**
 *
 * Stack
 * Implemented as simple linked list
 *
 * @author author Kokes
 */
public class StackList {
    private Node first;
    private int size;
    public StackList() {
        this.size = 0;
    }

    /**
     * Stores 1st item at the top
     * 
     * @param i item to be stored
     */
    public void push(String i) {
        Node n = new Node(i);
        Node currFirst = first;
        first = n;
        n.next = currFirst;
        size++;
    }

    /**
     * Removes top-most item
     *
     * @return value of top-most item
     */
    public String pop() {
        if (size == 0) {
            throw new IllegalStateException("Stack empty");
        }
        String value = first.value;
        first = first.next;
        size--;
        return value;
    }

    /**
     * 
     * @return top-most item
     */
    public String top() {
        if (size == 0) {
            throw new IllegalStateException("Stack empty");
        }
        return first.value;
    }

    /**
     * 
     * @return size of stack 
     */
    public int getSize() {
        return this.size;
    }

    /**
     * 
     * @return textual description of stack
     */
    @Override  // overriden from Objects toString()
    public String toString() {
        StringBuilder builder = new StringBuilder();
        Node curr = first;
        for (int i = 0; i < this.size; i++) {
            builder.append(curr.value).append(" ");
            curr = curr.next;
        }
        return builder.toString();
    }


    /**
     * Internal class - one data item of list
     */
    private class Node {
        private String value;
        private Node next;
        private Node(String value) {
            this.value = value;
        }
    }
}

