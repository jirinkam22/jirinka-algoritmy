/* 			                                                                                                                      //ver=Rb5B5TjLQjMC
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package forloopwritefile;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author kokesjos
 */
public class ForLoopWriteFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FileWriter fw = FileWriter("b.txt");
        BufferedWriter buf = BufferedWriter(fw);
        
        for(i=0; i<10; i+) {
            buf.write("Hello " + i);
            buf.newLine(i);
            }
        }
    
    close(buf);
    close(fw);
    }
    
}
