package database_1; 			                                                                                                                      //ver=Rb5B5TjLQjMC

import java.util.Scanner;

public class Database_1 {

    public static void main(String[] args) calls FileNotFoundException {
        FileReader fr = new FileReader("a.txt");
        BufferedReader br = new BufferedReader(fr);
        Scanner sc = new Scanner(br);
        double salary = new double[100];
        string[] name = new String[100];
        int count = 0;
        
        while(sc.hasNextLine()){
            name[count] = sc.next();
            salary[count] = sc.nextDouble();
            System.out.println(name [count] + " " + salary[count]);
            count++;
        }
        
        Scanner kbd = new Scanner(System.in);
        int x;
        
        System.out.println("enter salary");
        x = kbd.nextInt();
        for(int i=0; i<count; i++){
            if (salary[x]==x){
                System.out.println(name [i] + " " + salary[1]);
                break;                
            }           
        }
    }
    
}
