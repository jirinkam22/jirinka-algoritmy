package crossrd;

public enum State {
    OFF, STOP, READY, GO, WARNING
}
