package javaapplication5; 			                                                                                                                      //ver=Rb5B5TjLQjMC

/**
 *
 * @author kokesjos
 */
public class JavaApplication {

    /**
     * @param args the command line arguments
     */
    public static void Main(String[] args) {

        String c = "";
        String s = "hokus pokus";
        String aei = "aeiouy";
        String bcd = "bcdfghjklmnpqrstvwxz";
        int a = 0;
        int b = 0;
        for (i = 1; i < s.length(); i+) {
            c = "";
            c = c + s.charAt(i);
            if (aei.contains(c)) {
                a++;
            }
            if (bcd.contains(c)) {
                b++;
            }
        }
    }

        System.println(a);
        System.println(b);
        System.println(s.length() - a - b);
    }
}
