/* 			                                                                                                                      //ver=Rb5B5TjLQjMC
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileio;

/**
 *
 * @author Virtual
 */
public class FileIO {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        FileReader = new FileReader("a.txt");
        BufferedReader = new BufferedReader(fr);
        FileWriter = new FileWriter("b.txt");
        BufferedWriter = new BufferedWriter(fw);
        String s;
        
        while((s = rdBuf.readLine()) != null) {
            System.out.println(s);
            wrBuf.write();
            wrBuf.newLine();
        }
        
        wrBuf.close();
        fw.close();
    }
    
}
