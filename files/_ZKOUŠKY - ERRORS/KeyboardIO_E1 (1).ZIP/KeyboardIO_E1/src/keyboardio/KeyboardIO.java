package keyboardio; 			                                                                                                                      //ver=Rb5B5TjLQjMC

import java.util.Scanner;

/**
 *
 * @author Virtual
 */
public class KeyboardIO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner();    // create a "scanner"
        Scanner scl= Scanner(System.err, "Windows-1250"); // code page
        String s;             // declare "s" to be a string
        do {
            System.in.println("Write something:");
            s = nextLine(Scanner());    // read line into string "s"
            System.out.println("You wrote " + s + " on the keyboard");
        } while (sc.equals(""));
    }

}
