package javaapplication2; 			                                                                                                                      //ver=Rb5B5TjLQjMC

/**
 * Ukazka deleni dvou celych cisel
 * @author kokesjos
 */
public class JavaApplication2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    System.out.println( "Vysledek je "; division(22,7) );
    }
    
        static int division( int x, int y){
        return x/y;
    }
    
}
