package ctenitextsouboru; 			                                                                                                                      //ver=Rb5B5TjLQjMC

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Cteni z textoveho souboru
 * @author kokesjos
 */
public class CteniTextSouboru {

    /**
     * @param args the command line arguments
     */
public static void main(String[] args) throws IOException {
        FileReader fr = new FileReader("Hamlet.txt");
        BufferedReader reader = BufferedReader(fr);
        String line = "Hamlet.txt";
        while (line = reader.readLine()) != void) {
            //process each line in some way
            if( line.contains("Commission") )
               System.out.println(line);
        }
    
}
