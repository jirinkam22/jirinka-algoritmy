package trees;

/**
 * Toto je jen DEMO pro vyukove ucely,
 * upravene pro snadnejsi pochopeni.
 * Skutecny programator by nikdy nic
 * takoveho nenapsal!
 * 
 * ( prohledavaci cykly ve find()
 *    a insert() by sjednotil )
 * 
 * POZOR na porovnani == apod.!
 * Nejde udelat pro Sting, tam
 * se musi pouzit compareTo()
 * 
 * @author Kokes
 */
public class Node {
    public int key;
    public String data;
    public Node left = null;
    public Node right = null;    
    
    public Node(int aKey, String aData){
        key   = aKey;
        data  = aData;
        left  = null;
        right = null;                
    }
    
    public Node add(int aKey, String aData) { 
        if (aKey == key){
            System.err.println("duplicate key " + aKey);
            return null;                    
        } else if (aKey < key) { 
            if (left == null) { 
                left = new Node(aKey, aData); 
                return left; 
            } else 
                return left.add(aKey, aData); 
        } else if (aKey > key) { 
                if (right == null) { 
                    right = new Node(aKey, aData); 
                    return right; 
                } else 
                return right.add(aKey, aData); 
        } 
        return null; // for sure
      } 

    public Node find(int aKey){
        Node marker = this;
        while(marker != null){
            if (marker.key == aKey){
                // found
                break;
            } else if (marker.key < aKey){
                marker = marker.right;
            } else {
                marker = marker.left;
            }
        }
        return marker;    
    }
    
    
}
