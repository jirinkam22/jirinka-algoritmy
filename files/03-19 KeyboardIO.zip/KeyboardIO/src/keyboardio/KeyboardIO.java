/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package keyboardio;

import java.util.Scanner;

/**
 *
 * @author Virtual
 */
public class KeyboardIO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Napiš něco:");      // jednoduchý výstup
        System.out.println("Write something:"); // simple output
        
        Scanner sc = new Scanner(System.in);    // create a "scanner"
        String s = sc.nextLine();               // read line into string "s"
        
        System.out.println("Napsal jsi ");
        System.out.println(s + " na klávesnici");
        System.out.println("You wrote ");
        System.out.println(s + " on the keyboard");
    }
    
}
