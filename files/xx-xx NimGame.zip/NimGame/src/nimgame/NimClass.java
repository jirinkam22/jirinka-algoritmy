/*
 * Simplified NIM Game
 */
package nimgame;

import java.util.Random;

/**
 * Rules 
 * ===== 
 * On the pile is a predetermined number initCount of matches.
 * Players alternate taking, each player may take 1..maxTake matches. The player
 * who can no longer remove any match loses.
 *
 * Winning strategy 
 * ================ 
 * I must take so many matches to left 
 * (N * maxTake + 1) matches on the pile.
 *
 * @author Kokes
 */
public class NimClass {

    // variables (attibutes)
    private int maxTake;
    private int currentCount;
    Random rand = new Random(); // random number generator

    // constructor
    public NimClass(int initCount, int maxTake) {
        currentCount = initCount;
        this.maxTake = maxTake;
    }

    // get current count of matches as a String
    public String getCurrent() {
        return Integer.toString(currentCount);
    }

    // get current count of matches as an int
    public int getCurrentInt() {
        return currentCount;
    }

    // player takes
    public String takesPlayer(String count) {
        int playerTakes;
        playerTakes = Integer.valueOf(count);
        if ((playerTakes < 1) || (playerTakes > maxTake)) {
            System.err.println("Improper value " + count);
            return "ERR";
        }
        currentCount -= playerTakes;
        return Integer.toString(currentCount);
    }

    // computer takes
    public String takesComputer() {
        int compTakes;
        int reminder = currentCount % maxTake;
        // tests for end of game
        if (currentCount <= 0) {
            return "Player"; // player won
        } else if (currentCount <= maxTake) {
            return "Comp";   // computer won
        }
        // next take
        if (reminder == 0) {
            // random number 0..2 shifted to range 1..3
            compTakes = rand.nextInt(maxTake) + 1;
        } else {
            // reminder == 1 or 2
            compTakes = reminder;
        }
        currentCount -= compTakes;
        // result
        return Integer.toString(currentCount);        
    }

}
