/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semaphore;

import static javafx.scene.paint.Color.BLACK;
import static javafx.scene.paint.Color.GREEN;
import static javafx.scene.paint.Color.RED;
import static javafx.scene.paint.Color.YELLOW;
import javafx.scene.shape.Circle;

/**
 *
 * @author Virtual
 */
public class TrafficLight {
    private final Circle r, y, g;
    private int stav = 5;

    // konstruktor
    public TrafficLight(Circle redC, Circle yellowC, Circle greenC) {
        r = redC;
        y = yellowC;        
        g = greenC;
    }
    
    public void oneStep(){
        switch (stav){
            case 0: 
                r.setFill(RED); y.setFill(BLACK); g.setFill(BLACK); break;
            case 1: 
                r.setFill(RED); y.setFill(YELLOW); g.setFill(BLACK); break;
            case 2: 
                r.setFill(BLACK); y.setFill(BLACK); g.setFill(GREEN); break;
            case 3: 
                r.setFill(BLACK); y.setFill(YELLOW); g.setFill(BLACK); break;
            default: 
                r.setFill(BLACK); y.setFill(BLACK); g.setFill(BLACK); break;
        }
        stav = (stav+1) % 4;
    }
}
