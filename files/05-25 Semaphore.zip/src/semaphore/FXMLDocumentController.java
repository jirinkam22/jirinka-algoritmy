/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semaphore;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.shape.Circle;

/**
 *
 * @author Virtual
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML private Button btnGo;
    @FXML private Circle lightRed;
    @FXML private Circle lightYellow;
    @FXML private Circle lightGreen;
    
    private TrafficLight trafficLight;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        trafficLight.oneStep();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        trafficLight =  new TrafficLight(lightRed, lightYellow, lightGreen);
    }    
    
}
