/*
 * This Software is protected by copyright law and international treaties.
 * This Software is licensed (not sold), and its use is subject
 * to a valid WRITTEN AND SIGNED End User License Agreement (EULA).
 * The unauthorized use, copying or distribution of this Software
 * may result in severe criminal or civil penalties,
 * and will be prosecuted to the maximum extent allowed by law.
 */
package directsearchdemo;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author Kokes
 */
public class DirectSearch {
    private static String[] array = new String[1000000];
    
    public void readF(String fileName) throws FileNotFoundException{        
        int i;
        String s;
        Scanner scanner = new Scanner( new File(fileName), "CP1250" ); 
        while(scanner.hasNextInt()){
            i = scanner.nextInt();
            s = scanner.nextLine();            
            array[i] = s;            
        }
    }    
        
    public String find(int i){
        return array[i];
    }    
    
}
