/*
 * This Software is protected by copyright law and international treaties.
 * This Software is licensed (not sold), and its use is subject
 * to a valid WRITTEN AND SIGNED End User License Agreement (EULA).
 * The unauthorized use, copying or distribution of this Software
 * may result in severe criminal or civil penalties,
 * and will be prosecuted to the maximum extent allowed by law.
 */
package directsearchdemo;

import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *
 * @author Kokes
 */
public class DirectSearchDemo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        DirectSearch ds = new DirectSearch();
        ds.readF("patenty.txt");
        
        System.out.println(  ds.find(1404) );
        System.out.println(  ds.find(6594) );
    }
    
}
