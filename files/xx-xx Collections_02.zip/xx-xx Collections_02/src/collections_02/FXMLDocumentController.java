/*
 * This Software is protected by copyright law and international treaties.
 * This Software is licensed (not sold), and its use is subject
 * to a valid WRITTEN AND SIGNED End User License Agreement (EULA).
 * The unauthorized use, copying or distribution of this Software
 * may result in severe criminal or civil penalties,
 * and will be prosecuted to the maximum extent allowed by law.
 */
package collections_02;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author Kokes
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TextField tfInput;
    @FXML
    private TextField tfOutput;
    @FXML
    private TextArea taList;
    
    // instance of NewClass
    NewClass nc;
    
    // show formated list
    private void showAll(){
        String s = nc.getContentsFormated();
        taList.setText(s);
    }
    
    @FXML
    private void handleButtonRead(ActionEvent event) {
        String s;
        s = (String) nc.popItem();
        System.out.println("Read: " + s);
        tfOutput.setText(s);        
        showAll();
    }
    
    @FXML
    private void handleButtonWrite(ActionEvent event) {
        System.out.println("Write " + tfInput.getText());
        nc.pushItem( tfInput.getText() );
        tfInput.setText("");
        tfInput.requestFocus();
        showAll();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // create instance of NewClass
        nc = new NewClass<String>();
    }    
    
}
