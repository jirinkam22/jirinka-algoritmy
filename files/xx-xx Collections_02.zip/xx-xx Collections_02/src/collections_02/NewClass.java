package collections_02;

import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * @author Kokes
 */
public class NewClass<E> {
    
    // internal variables
    private LinkedList<E> queue = new LinkedList();
    
    // push string into list
    public void pushItem(E item){
        queue.addFirst(item);        
    }
    
    // pop string from the end of list
    public E popItem(){
        E e = queue.getLast();
        queue.removeLast();
        // alternatively: e = queue.pollLast();
        return e;
    }
    
    // list the whole contents
    public String getContents(){
        return queue.toString();
    }
    
    // list the formated whole contents
    public String getContentsFormated(){
        String s = "";
        ListIterator itr = queue.listIterator();
        while (itr.hasNext()){
            E element = (E) itr.next();
            s = s + element.toString() + "\n";
        }              
        return s;
    }
    
}
