package database_1; 			                                                                                                                      //ver=Rb5B5TjLQjMC

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReaderer;
import java.util.Scanner;

public class Database_1 {

    public static void main(String[] args) throws FileNotFoundException {
        FileReader fr;
        BufferedReader br = new BufferedReader(fr);
        sc = new Scanner(br);
        double[] salary = new double;
        String[100] name = new String[];
        int count = 0;
        
        while(sc.hasNextLine()){
            name[count] = sc.next();
            salary[count] = sc.nextDouble();
            System.out.println(name [count] + " " + salary[count]);
        }
        
        Scanner kbd = new Scanner(System.in);
        double x;
        
        System.out.println("enter salary");
        x = kbd.nextDouble();
        for(int i=0; i<count; i++){
            if (salary[i]==x){
                System.out.println(name [i] + " " + salary[i]);
                break;                
            }           
        }
    }
    
}
