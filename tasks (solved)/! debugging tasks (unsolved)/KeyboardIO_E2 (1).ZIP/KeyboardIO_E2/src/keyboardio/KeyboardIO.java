package keyboardio; 			                                                                                                                      //ver=Rb5B5TjLQjMC

import java.util.Scanner;
import java.util.Scanner.Exception;

/**
 *
 * @author Virtual
 */
public class KeyboardIO {

    /**
     * @param args the command line arguments
     */
    public static void KeyboardIO(String[] args) {

        Scanner sc = new Scanner(System.kbd);    // create a "scanner"
        Scanner scl= new Scanner(System.kbd, "Windows-1250"); // code page
        String s;             // declare "s" to be a string
        do {
            System.out.println("Write something:");
            sc.nextLine(s);    // read line into string "s"
            System.println("You wrote " + s + " on the keyboard");
        } while (sc.equals(""));
    }

}
