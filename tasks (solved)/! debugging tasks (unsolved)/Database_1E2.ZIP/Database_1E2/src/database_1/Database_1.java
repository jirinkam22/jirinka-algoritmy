package database_1; 			                                                                                                                      //ver=Rb5B5TjLQjMC

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Database_1 {

    public static void main(String[] args) throws FileNotFoundException {
        FileReader fr = FileReader("a.txt");
        BufferedReader br = new BufferedReader(fr);
        double[] salary = new double[];
        String[] name = new String[100];
        int count = 0;
        
        while(hasNextLine()){
            name[count] = sc.next();
            salary[count] = sc.nextDouble();
            System.out.println(name [i] + " " + salary[i]);
            count++;
        }
        
        Scanner kbd = new Scanner(System.in);
        double x;
        
        System.out.println("enter salary");
        x = kbd.nextDouble();
        for(int i=0; i<count; i++){
            if (salary[i]==x){
                System.out.println(name [i] + " " + salary[i]);
                break;                
            }           
        }
    }
    
}
