/* 			                                                                                                                      //ver=Rb5B5TjLQjMC
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reading;

/**
 *
 * @author kokesjos
 */
public class FileIO_scanner {

    /**
     * @param args the command line arguments                                                                                                                       training copy
     */
public static void main(String[] args) throws IOException {
        FileReader fr = FileReader("Hamlet.txt");
        BufferedReader reader = BufferedReader(fr);
        String line = null;
        while ((line = reader.readLine()) != null) {
            //process each line in some way
            if( line.contains("Horatio") )
               System.out.println(line);
        }

    }    
}
