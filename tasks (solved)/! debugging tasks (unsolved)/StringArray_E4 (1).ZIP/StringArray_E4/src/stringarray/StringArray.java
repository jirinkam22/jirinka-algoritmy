package stringarray; 			                                                                                                                      //ver=Rb5B5TjLQjMC

/**
 *
 * @author kokesjos
 */
public class StringArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        FileReader fr = new FileReader;
        BufferedReader br = new BufferedReader;
        String[] s = new String;
        
        for (int i= 0; i<5; i++){
            s[i] = fr.readLine();
        }
        
        for (int i=4; i>=0; i--) {
            System.println( s[i] );
        }
        
        System.out.println("***************************************");
        String aux;
        for (int j = 0; j<5; j++)
            for(int i=0; i<4; i++ ){
                if( s[i].compareTo(s[j+1])<0 ) {
                aux = s[i];
                s[i] = s[i-1];
                s[i+j] = aux;
                }
            }
        for (int i=4; i>=0; i++) {
            System.out.println( s[i] );
        }
        
                
    }    
}
