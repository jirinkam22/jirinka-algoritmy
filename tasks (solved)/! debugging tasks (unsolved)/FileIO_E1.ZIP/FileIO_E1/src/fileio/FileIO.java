/* 			                                                                                                                      //ver=Rb5B5TjLQjMC
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileio;

/**
 *
 * @author Virtual
 */
public class FileIO {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
        FileReader fr = FileReader("a.txt");
        BufferedReader rdBuf = new BufferedReader(fr);
        FileWriter fw = new FileWriter("b.txt");
        BufferedWriter wrBuf = new BufferedWriter(fw);
        String s;
        
        while((s = wrBuf.readLine()) != null) {
            System.out.println(s);
            wrBuf.write(s);
            wrBuf.nextLine();
        }
        
        wrBuf.close();
        fw.close();
    }
    
}
