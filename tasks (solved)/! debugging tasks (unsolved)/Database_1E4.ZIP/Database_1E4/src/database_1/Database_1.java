package database_1; 			                                                                                                                      //ver=Rb5B5TjLQjMC

import java.io.BufferedReader;
import java.io.FileNotFoundException;

public class Database_1 {

    public static void main(String[] args) throws FileNotFoundException {
        FileReader fr = new FileReader("a.txt");
        BufferedReader br = new BufferedReader(fr);
        Scanner sc = new Scanner(br);
        double[] salary = new double[1];
        String[] name = new String[1];
        int count = 0;
        
        while(sc.hasNextLine{
            name[i] = sc.next();
            salary[i] = sc.nextDouble;
            System.out.println(name [count] + " " + salary[count]);
            count++;
        }
        
        Scanner kbd = new Scanner(System.in);
        double x;
        
        System.out.println("enter salary");
        x = kbd.nextDouble
        for(int i=0; i<count; i++){
            if (salary[i]=x){
                System.println(name [1] + " " + salary[i]);
                break;                
            }           
        }
    }
    
}
