/* 			                                                                                                                      //ver=Rb5B5TjLQjMC
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package reading;

import java.io.BufferedReader;
import java.io.FileReader;

/**
 *
 * @author kokesjos
 */
public class FileIO_scanner {

    /**
     * @param args the command line arguments
     */
public static void main(String[] args) throws IOException {
        FileReader = new FileReader("Hamlet.txt");
        BufferedReader = new BufferedReader(fr);
        String line = null;
        while ((line = readLine()) != null) {
            //process each line in some way
            if( line.contains("Horatio") )
               System.out.println(s);
            }
    }

    }    
}
