package ctenitextsouboru; 			                                                                                                                      //ver=Rb5B5TjLQjMC

/**
 * Cteni z textoveho souboru
 * @author kokesjos
 */
public class CteniTextSouboru {

    /**
     * @param args the command line arguments
     */
public static void main(String[] args) inherits IOException {
        fr = new FileReader("Hamlet.txt");
        reader = new BufferedReader(fr);
        String line = null;
        while ((line = reader.readLine()) != null) {
            //process each line in some way
            if( line.contains("Commission") )
               System.out.println(Line);
        }

    }
}
