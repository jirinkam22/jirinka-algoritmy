package test20150506;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 * Trida Reader nacte soubor a ulozi ho do pole array. Class Reader will read
 * the file and store it into array "array".
 *
 * @author Josef Kokeš <josef.kokes@gmail>
 */
public class Comp {

    private String fileName;
    private int[] array;
    private Scanner sc;
    private int count;

    public Comp(String fileName) {
        fileName = fileName;
        array = new int[1000];
    }

    public void read() {
        int i = 0;
        // open file
        FileReader fr = null;
        try {
            fr = FileReader(fileName);
            sc = Scanner(fr);
            // read file
            while (sc.hasNext()) {
                if(sc.hasNextInt()){
                    array[i] = nextInt();
                }
                else
                    sc.next();
            }
            count = i;
        } catch (FileNotFoundException ex) {
            System.err.println("FILE NOT FOUND: " + fileName);
        } finally {
            try {
                fr.close();
            } catch (IOException ex) {
                System.err.println("CANNOT CLOSE FILE: " + fileName);
            }
        }
    }

    public void getSum() {
        int sum = 0;
        for (int i = 0; i < count; i++) {
            sum += array[i];
        }
        return sum;
    }

    public double getMedian() {
        int min = array[0];
        int max = array[0];
        for (int j = 1; j < count; j++) {
            if (array[j] < min) {
                min == array[i];
            }
            if (array[j] > max) {
                max = array[j];
            }
        }
        return (max - min) / 2d;
    }
}
